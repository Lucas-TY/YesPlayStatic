self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1285ede2b9ae3b439c14",
    "url": "/css/chunk-038a61ac.0f9c6ef5.css"
  },
  {
    "revision": "b9391b591d8bbe263ec4",
    "url": "/css/chunk-12051b3a.9f84654d.css"
  },
  {
    "revision": "622ed131c017920a8284",
    "url": "/css/chunk-14884344.5185b220.css"
  },
  {
    "revision": "e53de32285d8fc0598e9",
    "url": "/css/chunk-154d5eb8.bb0ce2f9.css"
  },
  {
    "revision": "c17b63aafa2f96f90376",
    "url": "/css/chunk-182f290c.0a6e1043.css"
  },
  {
    "revision": "0ce4ed125a50496c7536",
    "url": "/css/chunk-3617ea7a.03e7221f.css"
  },
  {
    "revision": "ccf905638f23fe1b07e9",
    "url": "/css/chunk-3f8180ff.3645394e.css"
  },
  {
    "revision": "2861562fe8068d8ec838",
    "url": "/css/chunk-417268ce.f465552d.css"
  },
  {
    "revision": "7ba09cb2821dcbcf7c1f",
    "url": "/css/chunk-43a738f4.ff31e5af.css"
  },
  {
    "revision": "e740d4da8fccde9b05c3",
    "url": "/css/chunk-51a1b2fe.42e9e76d.css"
  },
  {
    "revision": "6abfce5206f01e839493",
    "url": "/css/chunk-5647e7d7.babd9435.css"
  },
  {
    "revision": "838c9bd7056e1e16f88c",
    "url": "/css/chunk-57a4c13d.a172a377.css"
  },
  {
    "revision": "1d99f7b542eeb9ff8c14",
    "url": "/css/chunk-69859658.2a7e097e.css"
  },
  {
    "revision": "44e73c455eadd40daf6d",
    "url": "/css/chunk-69ff310d.e0326e71.css"
  },
  {
    "revision": "09fe502ebaf21a042360",
    "url": "/css/chunk-7092d8d0.ccd5fbf4.css"
  },
  {
    "revision": "3f8662e01d57928720f3",
    "url": "/css/chunk-936ce718.ed374ef2.css"
  },
  {
    "revision": "9481c2b90bb767642a54",
    "url": "/css/chunk-e8d39680.8829c628.css"
  },
  {
    "revision": "d4d75390082403b7b4bf",
    "url": "/css/chunk-vendors.c5cef460.css"
  },
  {
    "revision": "d11ece38036487d495ce",
    "url": "/css/index.aabd866b.css"
  },
  {
    "revision": "8e177a557add1e5add06a1b5e20465ce",
    "url": "/fonts/codicon.8e177a55.ttf"
  },
  {
    "revision": "e1e193ddd5b29a6605178bdd8d134246",
    "url": "/img/logos/netease-music.png"
  },
  {
    "revision": "2822cbcf68de083b96ac3921d0e308a2",
    "url": "/img/logos/nyancat.gif"
  },
  {
    "revision": "e099cb8ea828a912212f9022b96d248f",
    "url": "/img/logos/yesplaymusic.png"
  },
  {
    "revision": "299c141bf8b002f92e2d69df09fd226e",
    "url": "/img/touchbar/backward.png"
  },
  {
    "revision": "ab6f327d21116dd60adb02cadf8bcadf",
    "url": "/img/touchbar/forward.png"
  },
  {
    "revision": "f46e5d6308ff6d7b3c1ab74fe8f2c2a7",
    "url": "/img/touchbar/like.png"
  },
  {
    "revision": "9907a7f0207de6912daedc63353286a4",
    "url": "/img/touchbar/like_fill.png"
  },
  {
    "revision": "24007c3004310acf19e1a51ab4173541",
    "url": "/img/touchbar/next_up.png"
  },
  {
    "revision": "5e589bdadbd1513b0eac82cb58df2855",
    "url": "/img/touchbar/page_next.png"
  },
  {
    "revision": "8f3988bf4b0590ce24e248ecb946f3e3",
    "url": "/img/touchbar/page_prev.png"
  },
  {
    "revision": "fdafd5ac8a24471ff0270f6329495d0d",
    "url": "/img/touchbar/pause.png"
  },
  {
    "revision": "f4c8e812e62e581618c83fc277a7294b",
    "url": "/img/touchbar/play.png"
  },
  {
    "revision": "42df6d536c759fd26ad76d72c8eb533d",
    "url": "/img/touchbar/search.png"
  },
  {
    "revision": "eba46973408fa803c1bd709409add3bf",
    "url": "/index.html"
  },
  {
    "revision": "1285ede2b9ae3b439c14",
    "url": "/js/chunk-038a61ac.54943f88.js"
  },
  {
    "revision": "b9391b591d8bbe263ec4",
    "url": "/js/chunk-12051b3a.1422f368.js"
  },
  {
    "revision": "622ed131c017920a8284",
    "url": "/js/chunk-14884344.320d69e3.js"
  },
  {
    "revision": "e53de32285d8fc0598e9",
    "url": "/js/chunk-154d5eb8.802ba055.js"
  },
  {
    "revision": "c17b63aafa2f96f90376",
    "url": "/js/chunk-182f290c.77d52f63.js"
  },
  {
    "revision": "0ce4ed125a50496c7536",
    "url": "/js/chunk-3617ea7a.308b8c15.js"
  },
  {
    "revision": "ccf905638f23fe1b07e9",
    "url": "/js/chunk-3f8180ff.d5eef36f.js"
  },
  {
    "revision": "2861562fe8068d8ec838",
    "url": "/js/chunk-417268ce.52707321.js"
  },
  {
    "revision": "7ba09cb2821dcbcf7c1f",
    "url": "/js/chunk-43a738f4.521534e7.js"
  },
  {
    "revision": "e740d4da8fccde9b05c3",
    "url": "/js/chunk-51a1b2fe.6363394e.js"
  },
  {
    "revision": "6abfce5206f01e839493",
    "url": "/js/chunk-5647e7d7.2ea59ce1.js"
  },
  {
    "revision": "838c9bd7056e1e16f88c",
    "url": "/js/chunk-57a4c13d.6f57e082.js"
  },
  {
    "revision": "1d99f7b542eeb9ff8c14",
    "url": "/js/chunk-69859658.5076a7de.js"
  },
  {
    "revision": "44e73c455eadd40daf6d",
    "url": "/js/chunk-69ff310d.d80740c4.js"
  },
  {
    "revision": "09fe502ebaf21a042360",
    "url": "/js/chunk-7092d8d0.269ab680.js"
  },
  {
    "revision": "3f8662e01d57928720f3",
    "url": "/js/chunk-936ce718.1a4fffc4.js"
  },
  {
    "revision": "9481c2b90bb767642a54",
    "url": "/js/chunk-e8d39680.cb7b0e2e.js"
  },
  {
    "revision": "d4d75390082403b7b4bf",
    "url": "/js/chunk-vendors.b07544a5.js"
  },
  {
    "revision": "d11ece38036487d495ce",
    "url": "/js/index.60775a36.js"
  },
  {
    "revision": "b9d79419c8051857dbc1dedbc00e2ab2",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);